/*
 * Class: CMSC140 CRN
 * Instructor: Dr. Ahmed Tarek
 * Project 2
 * Description: Metric System Converter
 * Due Date: 10/08/2019
 * I pledge that I have completed the programming assignment independently.
   I have not copied the code from a student or any source.
   I have not given my code to any student.
   Print your Name here: Hassan Kane


 * Pseudocode or Algorithm for the program:
	(be sure to indent items with control structure)
	(need to match flow chart submitted in documentation)
	1.	User enters country name.
	2.	Display menu options that allow users to select a conversion from the Metric to the Imperial system.
	3.	Four options displayed include the choice to select: 1. Convert temperature, 2. Convert distance, 3. Convert weight & 4. To quit the program.
	4.	Error message will display if anything other than the options presented is selected
	5.	If the user enters 1, the program asks for the temperature in Celsius to be converted to Fahrenheit.
	6.	Redisplay country�s name
	7.	If the user enters 2, the program asks for the distance in Kilometer to be converted into Miles.
	8.	Error message will display if negative number is entered
	9.	Redisplay country�s name
	10.	If the user enters 3, the program asks for the weight in Kilogram to be converted into Pounds.
	11.	Error message will display if negative number is entered
	12.	Redisplay country�s name
	13.	If the user enters 4, the program should end.
 (more as needed)
*/

#include <iostream>
#include<string>
#include <iomanip>
#include <cmath>
using namespace std;

int main()
{
	string CountryName, ConverterToolkit, TemperatureConverter, DistanceConverter, WeightConverter, Quit, programmer, duedate;
	ConverterToolkit = "Converter Toolkit";
	TemperatureConverter = "Temperature Converter";
	DistanceConverter = "Distance Converter";
	WeightConverter = "Weight Converter";
	programmer = "Hassan Kane";
	duedate = "10/08/2019";
	Quit = "Quit";
	const int	TempConvertChoice = 1,
				DistConvertChoice = 2,
				WeightConvertChoice = 3,
				QuitCHoice = 4;
	int choice;
	int TempinC=20;
	int DistinKm=8;
	int WeightinKg=30;

	// User Enters Country Name
	cout << "Enter a country name:";
	getline (cin, CountryName);
	cout << endl;
	// Menu options are displayed
	cout << ConverterToolkit << endl;
	cout <<"-----------------" << endl;
	cout << TempConvertChoice <<". " << TemperatureConverter << endl;
	cout << DistConvertChoice <<". " << DistanceConverter << endl;
	cout << WeightConvertChoice<<". " << WeightConverter << endl;
	cout << QuitCHoice <<". "<< Quit << endl;
	cout << endl;
	//User enters any of the four options presented
	cout << "Enter your choice (1-4): ";
	cin>>choice;
	//If any option other than 1 through 4 are chosen, error message will display
	if (choice > 4)
	cout << "!!! Only 4 options, choose between 1 through 4 !!!";
	if (choice < 1)
	cout << "!!! Only 4 options, choose between 1 through 4 !!!";
	// If option 1 is chosen, convert temperature from Celsius to Farenheit
	if (choice == TempConvertChoice)
	{
		cout << "Please enter temperature in Celsius: ";
		cin >> TempinC;
		cout << "It is " << round(1.8 * TempinC + 32) << " in Farenheit.\n" << endl;
		cout << CountryName << " sounds fun!";	
	}
	//If option 2 is chosen, convert distance from kilometers to miles. Negative inputs will display an error message.
	if (choice == DistConvertChoice)
	{
		cout << fixed << showpoint << setprecision(2);
		cout << "Please enter distance in Kilometer: ";
		cin >> DistinKm;
			if ((DistinKm * 0.6) < 0)
			{
				cout << "!!! Program does not convert negative distance !!!\n" << endl;
			}
			if ((DistinKm * 0.6) > 0)
		cout << "It is " << (DistinKm * 0.6) << " in Miles.\n" << endl;
		cout << CountryName << " sounds fun!";
	}
	//If option 3 is chosen, convert weight from kilograms to pounds. Negative inputs will display an error message.
		cout << fixed << showpoint << setprecision(1);
	if (choice == WeightConvertChoice)
	{
			cout << "Please enter weight in kilograms: ";
			cin >> WeightinKg;
			if ((WeightinKg * 2.2) < 0)
			{
				cout << "!!! Program does not convert negative weight !!!\n" << endl;
			}
			if ((WeightinKg * 2.2) > 0)
			cout << "It is " << (WeightinKg * 2.2) << " in Pounds.\n" << endl;
			cout << CountryName << " sounds fun!";
				
	}
	//If option 4 is chosen, program will display goodbye message;
	else if (choice == QuitCHoice)
		cout << "Goodbye !!!";
	cout << endl;
	

	cout << "\nThanks for testing my program !!"<<endl;
	cout << "Programmer: " << programmer << endl;;
	cout << "CMSC 140 Project: " << 2<<endl;
	cout << "Due Date: " << duedate<<endl;



	system("pause");
	return 0;
}