#include <iostream>
#include<string>
#include <iomanip>
using namespace std;

int main()
{
	string name = "John Smith";
	int classpart = 89;
	int testscore = 87;
	int assignscore = 67;
	int examscore = 99;
	int practicescore = 80;
	float average = ((classpart + testscore + assignscore + examscore
		+ practicescore) / 5.0);

	cout << "Enter the Student's name: ";
	getline(cin, name);
	cout << "Enter Class Participation Score ranging from 0 to 100: ";
	cin >> classpart;
	cout << "Enter Test Score ranging from 0 to 100 : ";
	cin >> testscore;
	cout << "Enter Assignment Score ranging from 0 to 100 : ";
	cin >> assignscore;
	cout << "Enter Exam Score ranging from 0 to 100 : ";
	cin >> examscore; 
	cout << "Enter Practice Score ranging from 0 to 100 : ";
	cin >> practicescore;
	cout << name << ": " << "Final Score : " << (classpart + testscore + assignscore + examscore
		+ practicescore) << " Average Score : " << fixed<<showpoint << setprecision(1) << average << endl;

	system("pause");
	return 9;

}