#include<iostream>
#include<fstream>
#include<iomanip>
using namespace std;
ofstream outputFile;
int numofemployees;
int totalnumofabs = 0;
int employeeid;
int numberofdays;


void NumofEmployees()
{
	cout << "Calculate the average number of days a company's employees are absent.\n" << endl;
	cout << "Please enter the number of employees in the company: ";
	cin >> numofemployees;
	while (numofemployees < 1)
	{
		cout << "Number of employees can't be less than 1." << endl;
		cout << "Please re-enter the number of employees in the company : ";
		cin >> numofemployees;
	}
}

void TotDaysAbsent()
{
	outputFile.open("employeeAbsence.txt");
	outputFile << "EMPLOYEE ABSENCE REPORT" << endl;
	outputFile << " Employee ID  " << "  Days Absent " << endl;
	for (int ployee = 1; ployee <= numofemployees; ployee++)
	{
		cout << "Please enter an employee ID: ";
		cin >> employeeid;
		cout << "Please enter the number of days this employee was absent: ";
		cin >> numberofdays;
		if (numberofdays < 0)
		{
			cout << "Number of days can't be negative.\n";
			cout << "Please re-enter the number of days absent: ";
			cin >> numberofdays;
		}
		if (numberofdays > 365)
		{
			cout << "Number of days in the PAST YEAR.\n";
			cout << "Must Be Less Than 365. Re-enter the number of days absent: ";
			cin >> numberofdays;
		}
		totalnumofabs += numberofdays;
		outputFile << " " << employeeid << "	  " << "	" << numberofdays << endl;
	}
}

void AverageAbsent()
{
	outputFile << "The " << numofemployees << " employees were absent a total of " << totalnumofabs << " days." << endl;
	outputFile << "The average number of days absent is " << fixed << showpoint << setprecision(1) << double(totalnumofabs / numofemployees) << " days." << endl;
	outputFile << "\nProgrammer: Hassan Kane" << endl;
	outputFile.close();
	cout << "Programmer: Hassan Kane" << endl;
}

int main()
{
	NumofEmployees();
	TotDaysAbsent();
	AverageAbsent();
	system("pause");
	return 0;
}